from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.label import Label
import os

class DownloaderLayout(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(orientation='vertical', padding=10, spacing=10, **kwargs)

        self.title = Label(text='Music Downloader', font_size=24, size_hint=(1, 0.2))
        self.add_widget(self.title)

        self.url_input = TextInput(
            hint_text='Paste YouTube/Spotify/SoundCloud links here, one per line',
            multiline=True,
            size_hint=(1, 0.6)
        )
        self.add_widget(self.url_input)

        self.download_button = Button(
            text='Download Music',
            size_hint=(1, 0.2),
            background_color=(0.2, 0.6, 0.8, 1)
        )
        self.download_button.bind(on_press=self.download_music)
        self.add_widget(self.download_button)

        self.status = Label(text='', size_hint=(1, 0.2))
        self.add_widget(self.status)

    def download_music(self, instance):
        urls = self.url_input.text.strip().split('\n')
        for url in urls:
            if url:
                self.status.text = f'Downloading: {url}'
                os.system(f'spotdl "{url}"')
        self.status.text = 'Download complete.'

class MusicDownloaderApp(App):
    def build(self):
        return DownloaderLayout()

if __name__ == '__main__':
    MusicDownloaderApp().run()